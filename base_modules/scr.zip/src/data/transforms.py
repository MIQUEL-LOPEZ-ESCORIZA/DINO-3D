from monai import transforms

def mae3d_transforms(config, mode='train'):
    roi = config.MODEL.ROI
    
    # Define transforms for image and segmentation
    if mode == 'train' or mode == 'val':
        trans = transforms.Compose(
            [
                transforms.LoadImaged(
                    keys=["image","label"], 
                    image_only=False, 
                    allow_missing_keys=True,
                ),
                transforms.EnsureChannelFirstd(
                    keys=["image","label"],
                    allow_missing_keys=True,
                ),
                transforms.Orientationd(
                    keys=["image","label"], 
                    axcodes="RAS",
                    allow_missing_keys=True,
                ),
                transforms.Spacingd(
                    keys=["image","label"],
                    pixdim=(1.0, 1.0, 1.0),
                    mode=("bilinear", "nearest"),
                    allow_missing_keys=True
                ),
                transforms.CropForegroundd(
                    keys=["image","label"],
                    source_key="image",
                    allow_smaller=True,
                    allow_missing_keys=True,
                ),
                transforms.ScaleIntensityRanged(
                    keys=["image","label"],
                    a_min=40-150,
                    a_max=40+150,
                    b_min=0.0,
                    b_max=1.0,
                    clip=True,
                    allow_missing_keys=True,
                ),
                transforms.RandSpatialCropd(
                    keys=["image","label"],
                    roi_size=(roi[0], roi[1], roi[2]),
                    random_center=True,
                    random_size=False,
                    allow_missing_keys=True,
                ),
                transforms.ResizeWithPadOrCropd(
                    keys=["image","label"],
                    spatial_size=(roi[0], roi[1], roi[2]),
                    method='symmetric',
                    mode='constant',
                    value=0,
                    allow_missing_keys=True,
                ),
                transforms.RandFlipd(
                    keys=["image","label"], 
                    prob=0.1, 
                    spatial_axis=0,
                    allow_missing_keys=True,
                ),
                transforms.RandFlipd(
                    keys=["image","label"], 
                    prob=0.1, 
                    spatial_axis=1,
                    allow_missing_keys=True,
                ),
                transforms.RandFlipd(
                    keys=["image","label"], 
                    prob=0.1, 
                    spatial_axis=2,
                    allow_missing_keys=True,
                ),
                transforms.RandShiftIntensityd(
                    keys="image", 
                    offsets=0.1, 
                    prob=0.5,
                    allow_missing_keys=True,
                ),
                transforms.ToTensord(
                    keys=["image","label"],
                    allow_missing_keys=True,
                ),
            ]
        )
    elif mode == 'test':
        trans = transforms.Compose(
            [
                transforms.LoadImaged(
                    keys=["image", "label"], 
                    image_only=False,
                    allow_missing_keys=True,
                ),
                transforms.EnsureChannelFirstd(
                    keys=["image", "label"],
                    allow_missing_keys=True,
                ),
                transforms.Orientationd(
                    keys=["image","label"], 
                    axcodes="RAS",
                    allow_missing_keys=True,
                ),
                transforms.Spacingd(
                    keys=["image", "label"],
                    pixdim=(1.0, 1.0, 1.0),
                    mode=("bilinear", "nearest"),
                    allow_missing_keys=True,
                ),
                transforms.ScaleIntensityRanged(
                    keys=["image", "label"],
                    a_min=40-150,
                    a_max=40+150,
                    b_min=0.0,
                    b_max=1.0,
                    clip=True,
                    allow_missing_keys=True,
                ),
                transforms.CropForegroundd(
                    keys=["image", "label"],
                    source_key="image",
                    allow_smaller=False,
                    allow_missing_keys=True,
                ),
                transforms.RandSpatialCropd(
                    keys=["image", "label"],
                    roi_size=(roi[0], roi[1], roi[2]),
                    random_center=True,
                    random_size=False,
                    allow_missing_keys=True,
                ),
                transforms.ResizeWithPadOrCropd(
                    keys=["image","label"],
                    spatial_size=(roi[0], roi[1], roi[2]),
                    method='symmetric',
                    mode='constant',
                    value=0,
                    allow_missing_keys=True,
                ),
                transforms.ToTensord(
                    keys=["image", "label"],
                    allow_missing_keys=True,
                ),
            ]
        )
    else:
        raise NotImplementedError(f"{mode} mode not implemented.")
    
    return trans


def vit_transforms(config, mode='train'):
    roi = config.MODEL.ROI
    num_patches = config.VIT.NUM_PATCHES
    patches_overlap = config.VIT.PATCHES_OVERLAP
    
    # Define transforms for image and segmentation
    if mode == 'train':
        trans = transforms.Compose(
            [
                transforms.LoadImaged(
                    keys=["image", "label"],
                    image_only=False,
                    allow_missing_keys=True,
                ),
                transforms.EnsureChannelFirstd(
                    keys=["image", "label"],
                    allow_missing_keys=True,
                ),
                transforms.Orientationd(
                    keys=["image","label"],
                    axcodes="RAS",
                    allow_missing_keys=True,
                ),
                transforms.Spacingd(
                    keys=["image", "label"],
                    pixdim=(1.0, 1.0, 1.0),
                    mode=("bilinear", "nearest"),
                    allow_missing_keys=True,
                ),
                transforms.ScaleIntensityRanged(
                    keys=["image", "label"],
                    a_min=40-150,
                    a_max=40+150,
                    b_min=0.0,
                    b_max=1.0,
                    clip=True,
                    allow_missing_keys=True,
                ),
                transforms.CropForegroundd(
                    keys=["image", "label"],
                    source_key="image",
                    allow_smaller=False,
                    allow_missing_keys=True,
                ),
                transforms.SpatialPadd(
                    keys=["image", "label"],
                    spatial_size=[256, 256, 256],
                    method="symmetric",
                    mode="constant",
                    allow_missing_keys=True,
                ),
                # transforms.RandFlipd(
                #     keys=["image", "label"],
                #     prob=0.1,
                #     spatial_axis=0,
                #     allow_missing_keys=True,
                # ),
                # transforms.RandFlipd(
                #     keys=["image", "label"],
                #     prob=0.1,
                #     spatial_axis=1,
                #     allow_missing_keys=True,
                # ),
                # transforms.RandFlipd(
                #     keys=["image", "label"],
                #     prob=0.1,
                #     spatial_axis=2,
                #     allow_missing_keys=True,
                # ),
                # transforms.RandRotate90d(
                #     keys=["image", "label"],
                #     prob=0.1,
                #     max_k=3,
                #     allow_missing_keys=True,
                # ),
                # transforms.RandShiftIntensityd(
                #     keys="image",
                #     offsets=0.1,
                #     prob=0.5,
                #     allow_missing_keys=True,
                # ),
                transforms.GridPatchd(
                    keys=["image", "label"],
                    patch_size=(roi[0], roi[1], roi[2]),
                    num_patches=num_patches,
                    overlap=patches_overlap,
                    pad_mode="constant",
                    allow_missing_keys=True,
                ),
                transforms.ToTensord(
                    keys=["image", "label"],
                    allow_missing_keys=True,
                ),
            ]
        )
    elif mode == 'val' or mode == 'test':
        trans = transforms.Compose(
            [
                transforms.LoadImaged(
                    keys=["image", "label"],
                    image_only=False,
                    allow_missing_keys=True,
                ),
                transforms.EnsureChannelFirstd(
                    keys=["image", "label"],
                    allow_missing_keys=True,
                ),
                transforms.Orientationd(
                    keys=["image","label"],
                    axcodes="RAS",
                    allow_missing_keys=True,
                ),
                transforms.Spacingd(
                    keys=["image", "label"],
                    pixdim=(1.0, 1.0, 1.0),
                    mode=("bilinear", "nearest"),
                    allow_missing_keys=True,
                ),
                transforms.ScaleIntensityRanged(
                    keys=["image", "label"],
                    a_min=40-150,
                    a_max=40+150,
                    b_min=0.0,
                    b_max=1.0,
                    clip=True,
                    allow_missing_keys=True,
                ),
                transforms.CropForegroundd(
                    keys=["image", "label"],
                    source_key="image",
                    allow_smaller=False,
                    allow_missing_keys=True,
                ),
                transforms.SpatialPadd(
                    keys=["image", "label"],
                    spatial_size=[256, 256, 256],
                    method="symmetric",
                    mode="constant",
                    allow_missing_keys=True,
                ),
                transforms.GridPatchd(
                    keys=["image", "label"],
                    patch_size=(roi[0], roi[1], roi[2]), 
                    num_patches=num_patches,
                    overlap=patches_overlap,
                    pad_mode="constant",
                    allow_missing_keys=True,
                ),
                transforms.ToTensord(
                    keys=["image", "label"],
                    allow_missing_keys=True,
                ),
            ]
        )
    else:
        raise NotImplementedError(f"{mode} mode not implemented.")
    
    return trans
import os
import pandas as pd

from monai import data

import torch
import torch.distributed as dist
from torch.utils.data import Dataset, DataLoader

from src.utils.misc import create_dataset

############################
# Pre-Training
############################

def get_dataloaders(config, augs=[], class_idx=None):
    
    imtrans, imvals, imtests = augs[0], augs[1], augs[2]
    
    batch_size = config.DATA.BATCH_SIZE
    cache_dir = config.DATA.CACHE_DIR
    
    # Load Data
    df_train, df_val, df_test = pd.read_csv(config.DATA.TRAIN_CSV_PATH), \
        pd.read_csv(config.DATA.VAL_CSV_PATH), pd.read_csv(config.DATA.TEST_CSV_PATH)
    
    img_train = list(df_train['img_path'])
    img_val = list(df_val['img_path'])
    img_test = list(df_test['img_path'])
    
    # Create Dataset
    if class_idx == None:
        train_files = create_dataset(img_train, None)
        val_files = create_dataset(img_val, None)
        test_files = create_dataset(img_test, None)
    else:
        label_train = list(df_train.iloc[:, class_idx])
        label_val = list(df_val.iloc[:, class_idx])
        label_test = list(df_test.iloc[:, class_idx])
        
        train_files = create_dataset(img_train, label_train)
        val_files = create_dataset(img_val, label_val)
        test_files = create_dataset(img_test, label_test)
    
    num_tasks = dist.get_world_size()
    global_rank = dist.get_rank()
    
    # Create Dataloaders
    # Train
    train_ds = data.PersistentDataset(
        data=train_files, 
        transform=imtrans, 
        cache_dir=cache_dir,
    )
    sampler_train = torch.utils.data.distributed.DistributedSampler(
        train_ds,
        shuffle=True,
        num_replicas=num_tasks,
        rank=global_rank,
    )
    train_loader = data.ThreadDataLoader(
        train_ds,
        batch_size=batch_size,
        sampler=sampler_train,
        num_workers=config.DATA.NUM_WORKERS,
        pin_memory=config.DATA.PIN_MEMORY,
    )
    
    # Validate
    val_ds = data.PersistentDataset(
        data=val_files, 
        transform=imvals, 
        cache_dir=cache_dir, 
    )
    sampler_val = torch.utils.data.distributed.DistributedSampler(
        dataset=val_ds,
        shuffle=False,
        num_replicas=num_tasks,
        rank=global_rank,
    )
    val_loader = data.ThreadDataLoader(
        dataset=val_ds,
        batch_size=batch_size,
        sampler=sampler_val,
        num_workers=config.DATA.NUM_WORKERS,
        pin_memory=config.DATA.PIN_MEMORY,
    )
    
    # Test
    test_ds = data.PersistentDataset(
        data=test_files, 
        transform=imtests, 
        cache_dir=cache_dir, 
    )
    sampler_test = torch.utils.data.distributed.DistributedSampler(
        dataset=test_ds,
        shuffle=False,
        num_replicas=num_tasks,
        rank=global_rank,
    )
    test_loader = data.ThreadDataLoader(
        dataset=test_ds,
        batch_size=batch_size,
        sampler=sampler_test,
        num_workers=config.DATA.NUM_WORKERS,
        pin_memory=config.DATA.PIN_MEMORY,
    )
    
    return train_loader, val_loader, test_loader


def get_one_dataloader(config, aug):
    batch_size = config.DATA.BATCH_SIZE
    cache_dir = config.DATA.CACHE_DIR
    
    # Load Data
    df = pd.read_csv(config.DATA.TEST_CSV_PATH)
    imgs = list(df['img_path'])
    
    # Create Dataset
    files = create_dataset(imgs, None)
    
    num_tasks = dist.get_world_size()
    global_rank = dist.get_rank()
    
    # Create Dataloaders
    # Test
    ds = data.PersistentDataset(
        data=files, 
        transform=aug, 
        cache_dir=cache_dir, 
    )
    sampler = torch.utils.data.distributed.DistributedSampler(
        dataset=ds,
        shuffle=False,
        num_replicas=num_tasks,
        rank=global_rank,
    )
    loader = data.ThreadDataLoader(
        dataset=ds,
        batch_size=batch_size,
        sampler=sampler,
        num_workers=config.DATA.NUM_WORKERS,
        pin_memory=config.DATA.PIN_MEMORY,
    )
    
    return loader

############################
# Linear-Probing/Fine-Tuning
############################

class CustomDataset(Dataset):
    def __init__(self, dataset_name, class_idx):
        self.dataset = pd.read_csv(dataset_name)
        self.class_idx = class_idx

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        fname = self.dataset.iloc[idx, 0]
        label = self.dataset.iloc[idx, self.class_idx]
        return fname, label

def get_finetune_dataloaders(config, augs=[], class_idx=1):
    
    #imtrans, imvals, imtests = augs[0], augs[1], augs[2]
    
    batch_size = config.DATA.BATCH_SIZE
    
    num_tasks = dist.get_world_size()
    global_rank = dist.get_rank()
    
    # Create Dataloaders
    # Train
    train_ds = CustomDataset(
        config.DATA.TRAIN_CSV_PATH, 
        class_idx,
    )
    sampler_train = torch.utils.data.distributed.DistributedSampler(
        train_ds,
        shuffle=True,
        num_replicas=num_tasks,
        rank=global_rank,
    )
    train_loader = DataLoader(
        train_ds,
        batch_size=batch_size,
        sampler=sampler_train,
        num_workers=config.DATA.NUM_WORKERS,
        pin_memory=config.DATA.PIN_MEMORY,
    )
    
    # Validate
    val_ds = CustomDataset(
        config.DATA.VAL_CSV_PATH, 
        class_idx,
    )
    sampler_val = torch.utils.data.distributed.DistributedSampler(
        val_ds,
        shuffle=False,
        num_replicas=num_tasks,
        rank=global_rank,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=batch_size,
        sampler=sampler_val,
        num_workers=config.DATA.NUM_WORKERS,
        pin_memory=config.DATA.PIN_MEMORY,
    )
    
    # Test
    test_ds = CustomDataset(
        config.DATA.TEST_CSV_PATH, 
        class_idx,
    )
    sampler_test = torch.utils.data.distributed.DistributedSampler(
        test_ds,
        shuffle=False,
        num_replicas=num_tasks,
        rank=global_rank,
    )
    test_loader = DataLoader(
        test_ds,
        batch_size=batch_size,
        sampler=sampler_test,
        num_workers=config.DATA.NUM_WORKERS,
        pin_memory=config.DATA.PIN_MEMORY,
    )
    
    return train_loader, val_loader, test_loader
